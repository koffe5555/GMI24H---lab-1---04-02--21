﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Lab1_Kristoffer
{
    class Program
    {
        static void Main(string[] args)
        {
            //Random Array
            Random rnd = new Random();
            Random randNum = new Random();
            int number = rnd.Next(5,30);
            int[] myArray = new int[rnd.Next(5,30)];
            for (int i = 0; i < myArray.Length; i++)
            {
                myArray[i] = randNum.Next(0, 20);  
            }


            //Uppgift 1
            Console.WriteLine("Uppgift 1: \n");
            //ArrayCounter(myArray, number);
            Console.WriteLine("-----------------------------------------------------------------");

            //Uppgift 2 - Brute Force Array
            int[] arrayA = {7, 4, 9, 2, 6, 1, 3, 9, 2, 10, 8, 2, 3, 5, 1, 8, 8};
            int[] arrayB = {7, 1, 6, 8, 5, 11, 2, 23, 15};
            Console.WriteLine("Uppgift 2 Bruteforce: \n");
            //BruteForce(myArray);
            Console.WriteLine("-----------------------------------------------------------------");

            //Uppgift 2 - Algoritm
            Console.WriteLine("Uppgift 2 Algorithem: \n");
            //ArrayDifference(myArray);
            Console.WriteLine("-----------------------------------------------------------------"); 

            //Uppgift 3A
            Console.WriteLine("Uppgift 3A 'slower': \n");
            int[] reverseArray = {0, 3, 8, 16, 32, 55, 88, 93, 102, 120, 140, 155, 200, 300, 301, 302, 400, 500, 1000};
            ReverseSlower(reverseArray);
            Console.WriteLine("-----------------------------------------------------------------");

            Console.WriteLine("Uppgift 3B 'faster': \n");
            ReverseFaster(reverseArray);
            Console.WriteLine("-----------------------------------------------------------------");            
        }

        private static void ReverseSlower(int[] reverseArray)
        {
            DateTime startTime = DateTime.Now;
            StringBuilder csv = new StringBuilder();

            int i = 1;
            while(i < reverseArray.Length)
            {
                int nextVal = reverseArray[i];
                int j = i;
                while(j > 0)
                {
                    reverseArray[j] = reverseArray[j - 1];
                    j--;
                }
                reverseArray[0] = nextVal;
                i++;
            }
            DateTime stopTime = DateTime.Now;
            TimeSpan elapsed = stopTime - startTime;
            Console.WriteLine("The reverse Array: "+string.Join(" ",reverseArray));
            Console.WriteLine("Time: "+elapsed.ToString().Substring(7));

            int arrLenght = reverseArray.Length;
            string n = arrLenght.ToString();
            string csvElapsed = elapsed.ToString();
            var csvText = String.Format("{0};{1};",csvElapsed.Substring(7),n);
            csv.Append(csvText);

            string newFileName = "resultsuppgift3_a.csv";
            if (!File.Exists(newFileName))
            {
                string clientheader = ("Time" + "," + "Count" + Environment.NewLine);
                File.WriteAllText(newFileName, clientheader);
            }
            File.AppendAllText(newFileName, csv.ToString() + Environment.NewLine);

        }

        private static void ReverseFaster(int[] reverseArray)
        {
            DateTime startTime = DateTime.Now;
            StringBuilder csv = new StringBuilder();

            int Length = reverseArray.Length - 1;
            string StrReverse = null;
            while(Length >= 0)
            {
                StrReverse = StrReverse + " "+reverseArray[Length];
                Length--;
            }
            //string origianArray = string.Join(" ",myArray);

            DateTime stopTime = DateTime.Now;
            TimeSpan elapsed = stopTime - startTime;
            //Console.WriteLine("The original Array: "+origianArray);
            Console.WriteLine("The array reversed: "+StrReverse+"\n"+"Time: "+elapsed.ToString().Substring(7));

            int arrLenght = reverseArray.Length;
            string n = arrLenght.ToString();
            string csvElapsed = elapsed.ToString();
            var csvText = String.Format("{0};{1};",csvElapsed.Substring(7),n);
            csv.Append(csvText);

            string newFileName = "resultsuppgift3.csv";
            if (!File.Exists(newFileName))
            {
                string clientheader = ("Time" + "," + "Count" + Environment.NewLine);
                File.WriteAllText(newFileName, clientheader);
            }
            File.AppendAllText(newFileName, csv.ToString() + Environment.NewLine);
        }

        private static void ArrayCounter(int[] myArray, int number)
        {
            DateTime startTime = DateTime.Now;
            StringBuilder csv = new StringBuilder();
            
            int count = 0;
            //Loop trough the array and check if the numbers in the array is = to int number
            foreach(var item in myArray)
            {
                //We can add the or statement to check for negative of the same number also
                Console.WriteLine("Nummer i arrayen: "+item);
                if(item == number /*|| item == number*-1*/)
                {
                    count += 1;
                }
            }  
            Console.WriteLine("Talet: "+number+" Förekommer: "+count+" gånger"); 
            DateTime stopTime = DateTime.Now;
            TimeSpan elapsed = stopTime - startTime;
            
            Console.WriteLine("Time: "+elapsed.ToString().Substring(7));


            //To csv        
            string newFileName = "results.csv";
            string csvCount = count.ToString();
            string csvElapsed = elapsed.ToString();
            var csvText = String.Format("{0};{1};",csvElapsed.Substring(7),csvCount);
            csv.Append(csvText);
            if(!File.Exists(newFileName))
            {
                string clientheader = ("Time" + "," + "Count"+Environment.NewLine);
                File.WriteAllText(newFileName, clientheader);
            }
            File.AppendAllText(newFileName, csv.ToString() + Environment.NewLine);
        }

        private static int BruteForce(int[] myArray)
        {
            DateTime startTime = DateTime.Now;
            int bigNumA = 0;
            foreach(int i in myArray)
            {
                foreach(int j in myArray)
                {
                    int newNum = i - j;
                    if(newNum > bigNumA)
                    {
                        bigNumA = newNum;
                    }
                }
            }

            DateTime stopTime = DateTime.Now;
            TimeSpan elapsed = stopTime - startTime;
            StringBuilder csv = new StringBuilder();
            Console.WriteLine("Time: "+elapsed.ToString().Substring(7)+"\n"+"Result: "+bigNumA+"\n");

            string newFileName = "results_uppgit_2.csv";
            string csvCount = bigNumA.ToString();
            string csvElapsed = elapsed.ToString();
            var csvText = String.Format("{0};{1};",csvElapsed.Substring(7),csvCount);
            csv.Append(csvText);
            if(!File.Exists(newFileName))
            {
                string clientheader = ("Time" + "," + "Count"+Environment.NewLine);
                File.WriteAllText(newFileName, clientheader);
            }
            File.AppendAllText(newFileName, csv.ToString() + Environment.NewLine);

            return bigNumA;
        }
        private static int ArrayDifference(int[] myArray)
        {
            DateTime startTime = DateTime.Now;
            int small_num = 0;
            int biggest_num = 0;

            if (myArray.Length > 0) small_num = biggest_num = myArray[0];

            for (int i = 1; i < myArray.Length; i++)
            {
                small_num = Math.Min(small_num, myArray[i]);
                biggest_num = Math.Max(biggest_num, myArray[i]);
            }
            int result = biggest_num - small_num;
            DateTime stopTime = DateTime.Now;
            TimeSpan elapsed = stopTime - startTime;
            Console.WriteLine("Time: "+elapsed.ToString().Substring(7)+"\n"+"Result: "+result);

            StringBuilder csv = new StringBuilder();
            string newFileName = "results_uppgit_2_algo.csv";
            string csvCount = result.ToString();
            string csvElapsed = elapsed.ToString();
            var csvText = String.Format("{0};{1};",csvElapsed.Substring(7),csvCount);
            csv.Append(csvText);
            if(!File.Exists(newFileName))
            {
                string clientheader = ("Time" + "," + "Count"+Environment.NewLine);
                File.WriteAllText(newFileName, clientheader);
            }
            File.AppendAllText(newFileName, csv.ToString() + Environment.NewLine);            
            return result; 
        }
    }
}
